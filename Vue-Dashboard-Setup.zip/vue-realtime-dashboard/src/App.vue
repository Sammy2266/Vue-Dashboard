<script setup lang="ts">
import DashboardLayout from './components/layout/DashboardLayout.vue'
import Dashboard from './components/Dashboard.vue'
</script>

<template>
  <DashboardLayout>
    <Dashboard />
  </DashboardLayout>
</template>

<style>
html, body {
  margin: 0;
  padding: 0;
  font-family: 'Inter', 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  height: 100%;
  background-color: #f5f7fa;
  color: #2c3e50;
}

* {
  box-sizing: border-box;
}
</style>
